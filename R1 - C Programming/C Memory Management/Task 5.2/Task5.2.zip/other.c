#include "header.h"

// Only in this file you can directly call malloc, realloc, etc.
#undef malloc

void *alloc (size_t size){


  void *mempool;

  mempool = malloc(size);

  if (mempool != NULL) return mempool;
  
  else {
    printf("Out of memory");
    exit(EXIT_FAILURE);
  }

}

// Definition for initialize_memory


// Definition for show_memory